public class TripType {
    public static final Trip.TripType FLIGHT = Trip.TripType.FLIGHT;
    public static final Trip.TripType HOTEL = Trip.TripType.HOTEL;
    public static final Trip.TripType PACKAGE = Trip.TripType.PACKAGE;
}
